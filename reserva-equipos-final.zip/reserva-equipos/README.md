# Sistema de reserva de equipos informáticos

Aplicación web de clase para reservar equipos del centro por **fecha y turno (mañana o tarde)**. Está hecha con Node.js, Express, EJS y JavaScript, con un núcleo de reservas adicional en TypeScript. La estructura sigue la separación trabajada en las sesiones: rutas, controladores, servicios, repositorios, vistas, parciales y modelos de vista.

## 1. Requisitos e instalación

- Node.js 20.6 o superior (recomendado Node.js 22 LTS).
- npm.

Desde la carpeta del proyecto:

```bash
npm install
cp .env.example .env
```

Edita `.env` y cambia `SESSION_SECRET` por un secreto aleatorio de al menos 32 caracteres. Puedes generarlo con:

```bash
node -e "console.log(require('node:crypto').randomBytes(32).toString('hex'))"
```

Arranca la aplicación:

```bash
npm start
```

Abre http://localhost:3000. Para desarrollo con reinicio automático usa `npm run dev`.

## 2. Cuentas de prueba

| Rol | Correo | Contraseña |
|---|---|---|
| Administrador | admin@example.com | admin123 |
| Usuario | ana@example.com | clave123 |
| Usuario | luis@example.com | clave123 |

Son cuentas locales para comprobar la práctica. Las contraseñas se guardan mediante bcrypt. El registro público siempre crea usuarios con rol `usuario`; el navegador no puede elegir el rol.

## 3. Funcionalidades y rutas

### Catálogo público

- `GET /equipos`: lista equipos.
- `GET /equipos?tipo=portatil` o `?tipo=sobremesa`: filtra por tipo.
- `GET /equipos?operativos=true`: muestra solo equipos operativos.
- `GET /equipos/:id`: muestra la ficha del equipo.
- `POST /preferencias`: guarda el tipo preferido (`portatil` o `sobremesa`) en una cookie propia. Se usa como filtro inicial del catálogo y nunca para autorizar.

### Usuarios y sesiones

- `GET/POST /registro`: registro con validación y correo no duplicado.
- `GET/POST /login`: comprobación con bcrypt y límite de intentos.
- `POST /logout`: destruye la sesión y elimina la cookie.
- `GET /perfil`: requiere sesión.

Después del login se regenera el identificador de sesión y se guarda únicamente `userId` como dato de identidad. El usuario actual se vuelve a cargar desde el repositorio. Las vistas nunca reciben `passwordHash`.

### Reservas

- `GET /reservas/nueva?fecha=AAAA-MM-DD&turno=manana`: consulta equipos disponibles.
- `POST /reservas`: crea una reserva.
- `GET /mis-reservas`: muestra las reservas propias, activas y canceladas.
- `POST /reservas/:id/cancelar`: cancela una reserva propia, activa y cuya fecha no haya pasado.

El servidor valida de nuevo equipo, fecha, turno, estado y conflictos al recibir el POST. El usuario se obtiene de la sesión, no del formulario. Una reserva cancelada conserva su registro y deja libre el turno.

### Administración

- `GET/POST /admin/equipos`: consulta y añade equipos.
- `POST /admin/equipos/:id/estado`: cambia entre `operativo` y `fuera_de_servicio`.
- `GET /admin/reservas`: consulta todas las reservas.
- `POST /admin/reservas/:id/cancelar`: cancela cualquier reserva activa.

Todas estas rutas requieren el rol `admin`, comprobado con el usuario cargado desde el servidor.

## 4. Seguridad

- Middleware reutilizable de autenticación y autorización por roles.
- Comprobación de propiedad de reservas.
- Token CSRF vinculado a la sesión en todos los formularios POST, incluido logout.
- `express-rate-limit` para limitar intentos de login.
- Cookies de sesión con `httpOnly`, `sameSite: lax`, caducidad y `secure` en producción.
- Cookie de preferencia separada de la identidad y los permisos.
- Validación de datos, errores de dominio y manejador centralizado sin trazas ni secretos en las respuestas.
- Uso de `303` después de operaciones correctas (Post/Redirect/Get), `400` para datos incorrectos, `401` para credenciales incorrectas, `403` para permisos/CSRF, `404` para recursos inexistentes y `409` para conflictos.

## 5. Organización del código

- `src/routes`: métodos HTTP, URL y middleware de cada ruta.
- `src/controllers`: lectura de la petición, coordinación de servicios y respuesta HTTP.
- `src/services`: reglas de negocio; no dependen de `req`, `res` ni EJS.
- `src/repositories`: acceso a las colecciones en memoria.
- `src/domain`: validaciones, disponibilidad y errores de dominio.
- `src/middleware`: sesión, usuario actual, CSRF, flash, preferencias, autenticación y errores.
- `src/viewmodels`: datos preparados para formularios.
- `views`: páginas EJS y parciales reutilizables.
- `ts`: interfaces, tipos unión, repositorio con `Map` y servicio con inyección de dependencias.

La aplicación se exporta desde `src/app.js`; `src/server.js` es el único archivo que abre el puerto. Así Supertest puede probar la aplicación sin arrancar un servidor manualmente.

## 6. TypeScript y pruebas

```bash
npm run build
npm test
npm run check
```

La compilación usa `strict: true` y `noEmitOnError: true`. Las pruebas utilizan Vitest y Supertest, con un agente que conserva las cookies de sesión. Cubren registro, login incorrecto, rutas privadas, roles, reserva válida y duplicada, propiedad de cancelación, CSRF y logout.

## 7. Ejemplos curl

El archivo `docs/curl-examples.md` contiene ejemplos para las rutas públicas, registro, login, logout, preferencias, reservas y administración. `docs/guia-defensa.md` resume cómo explicar la arquitectura, sesiones, permisos, CSRF y TypeScript en la evaluación. Los formularios usan token CSRF: primero se solicita la página con `curl`, se conserva la cookie y se extrae el valor `_csrf` del HTML para enviarlo en el POST.

## 8. Datos y límites

Los equipos, usuarios y reservas se almacenan en colecciones en memoria mediante repositorios. Al reiniciar el proceso se recuperan los datos iniciales y se pierden los cambios realizados durante la ejecución. `express-session` usa el almacén MemoryStore por simplicidad didáctica; no es apropiado para producción ni para varios procesos. Para un despliegue real harían falta una base de datos, un almacén de sesiones persistente, HTTPS y gestión de secretos.

## 9. Publicación en GitHub

Crea un repositorio en GitHub y, desde la carpeta del proyecto, ejecuta los comandos siguientes sustituyendo la URL por la del repositorio que hayas creado:

```bash
git init
git add .
git commit -m "Entrega sistema de reserva de equipos"
git branch -M main
git remote add origin URL_DE_TU_REPOSITORIO
git push -u origin main
```

El repositorio debe ser público o estar compartido con `manuel.granados@eusa.es`. Comprueba que el último commit se ha realizado antes de la fecha límite.

## 10. Uso de inteligencia artificial

La IA se puede utilizar como apoyo para consultar dudas, explicar errores y revisar el código. El alumno debe comprender el proyecto, comprobar su funcionamiento y poder explicar y modificar sus partes durante la evaluación. **Antes de entregar, crea un enlace compartido a esta conversación y pégalo aquí:** `[PENDIENTE: enlace compartido del historial de IA]`. No se debe sustituir por la página general de ChatGPT.
