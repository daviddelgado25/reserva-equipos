# Ejemplos HTTP reproducibles con curl

Ejecuta primero `npm install`, copia `.env.example` a `.env`, cambia `SESSION_SECRET` y arranca con `npm start`. Los formularios que modifican datos necesitan una sesión y un token CSRF. Conserva la cookie con `-b` y `-c`.

En los ejemplos se usa una fecha futura calculada con Node:

```bash
FECHA=$(node -e "const d=new Date(); d.setDate(d.getDate()+2); console.log(new Date(d.getTime()-d.getTimezoneOffset()*60000).toISOString().slice(0,10))")
```

## 1. Catálogo público y filtros

```bash
curl -i http://localhost:3000/equipos
curl -i 'http://localhost:3000/equipos?tipo=portatil'
curl -i 'http://localhost:3000/equipos?tipo=sobremesa'
curl -i 'http://localhost:3000/equipos?operativos=true'
curl -i 'http://localhost:3000/equipos?tipo=portatil&operativos=true'
curl -i http://localhost:3000/equipos/1
```

## 2. Preferencia de tipo de equipo

```bash
curl -s -c usuario.cookies http://localhost:3000/equipos -o catalogo.html
TOKEN=$(grep -o 'name="_csrf" value="[^"]*"' catalogo.html | head -1 | cut -d '"' -f 4)
curl -i -b usuario.cookies -c usuario.cookies -X POST http://localhost:3000/preferencias \
  --data-urlencode "_csrf=$TOKEN" --data-urlencode 'tipo=portatil'
# El siguiente catálogo aplica el filtro de portátil si no se indica otro.
curl -i -b usuario.cookies http://localhost:3000/equipos
```

## 3. Registro

```bash
curl -s -c usuario.cookies http://localhost:3000/registro -o registro.html
TOKEN=$(grep -o 'name="_csrf" value="[^"]*"' registro.html | head -1 | cut -d '"' -f 4)
curl -i -b usuario.cookies -c usuario.cookies -X POST http://localhost:3000/registro \
  --data-urlencode "_csrf=$TOKEN" \
  --data-urlencode 'nombre=Usuario de prueba' \
  --data-urlencode 'email=prueba@example.test' \
  --data-urlencode 'password=contrasena123'
```

El registro público crea siempre el rol `usuario`; no acepta el rol enviado por el navegador.

## 4. Inicio de sesión, perfil y cierre

```bash
curl -s -c usuario.cookies http://localhost:3000/login -o login.html
TOKEN=$(grep -o 'name="_csrf" value="[^"]*"' login.html | head -1 | cut -d '"' -f 4)
curl -i -b usuario.cookies -c usuario.cookies -X POST http://localhost:3000/login \
  --data-urlencode "_csrf=$TOKEN" \
  --data-urlencode 'email=ana@example.com' \
  --data-urlencode 'password=clave123'
curl -i -b usuario.cookies http://localhost:3000/perfil

curl -s -b usuario.cookies -c usuario.cookies http://localhost:3000/perfil -o perfil.html
TOKEN=$(grep -o 'name="_csrf" value="[^"]*"' perfil.html | head -1 | cut -d '"' -f 4)
curl -i -b usuario.cookies -c usuario.cookies -X POST http://localhost:3000/logout \
  --data-urlencode "_csrf=$TOKEN"
```

## 5. Reservas de usuario

Vuelve a iniciar sesión como Ana antes de continuar. El equipo 4 está operativo y la fecha elegida está dos días en el futuro.

```bash
curl -s -b usuario.cookies -c usuario.cookies http://localhost:3000/login -o login.html
TOKEN=$(grep -o 'name="_csrf" value="[^"]*"' login.html | head -1 | cut -d '"' -f 4)
curl -i -b usuario.cookies -c usuario.cookies -X POST http://localhost:3000/login \
  --data-urlencode "_csrf=$TOKEN" --data-urlencode 'email=ana@example.com' --data-urlencode 'password=clave123'
```

```bash
curl -s -b usuario.cookies -c usuario.cookies \
  "http://localhost:3000/reservas/nueva?fecha=$FECHA&turno=tarde" -o nueva-reserva.html
TOKEN=$(grep -o 'name="_csrf" value="[^"]*"' nueva-reserva.html | head -1 | cut -d '"' -f 4)
curl -i -b usuario.cookies -c usuario.cookies -X POST http://localhost:3000/reservas \
  --data-urlencode "_csrf=$TOKEN" --data-urlencode 'equipoId=4' \
  --data-urlencode "fecha=$FECHA" --data-urlencode 'turno=tarde'
curl -i -b usuario.cookies http://localhost:3000/mis-reservas
```

Para cancelar una reserva propia, abre `/mis-reservas`, identifica su número, extrae el token CSRF del HTML y envía:

```bash
curl -s -b usuario.cookies -c usuario.cookies http://localhost:3000/mis-reservas -o mis-reservas.html
TOKEN=$(grep -o 'name="_csrf" value="[^"]*"' mis-reservas.html | head -1 | cut -d '"' -f 4)
# Sustituye ID por el identificador de una reserva propia, activa y futura.
curl -i -b usuario.cookies -c usuario.cookies -X POST http://localhost:3000/reservas/ID/cancelar \
  --data-urlencode "_csrf=$TOKEN"
```

## 6. Administración

Inicia sesión con `admin@example.com` y contraseña `admin123`, usando un archivo de cookies distinto. El token se obtiene siempre de la página del formulario que se va a enviar.

```bash
curl -s -c admin.cookies http://localhost:3000/login -o admin-login.html
TOKEN=$(grep -o 'name="_csrf" value="[^"]*"' admin-login.html | head -1 | cut -d '"' -f 4)
curl -i -b admin.cookies -c admin.cookies -X POST http://localhost:3000/login \
  --data-urlencode "_csrf=$TOKEN" --data-urlencode 'email=admin@example.com' --data-urlencode 'password=admin123'

# Consultar equipos y añadir uno nuevo.
curl -s -b admin.cookies -c admin.cookies http://localhost:3000/admin/equipos -o admin-equipos.html
TOKEN=$(grep -o 'name="_csrf" value="[^"]*"' admin-equipos.html | head -1 | cut -d '"' -f 4)
curl -i -b admin.cookies -c admin.cookies -X POST http://localhost:3000/admin/equipos \
  --data-urlencode "_csrf=$TOKEN" --data-urlencode 'codigo=PORT-099' \
  --data-urlencode 'nombre=Portatil de pruebas' --data-urlencode 'tipo=portatil'

# Cambiar el estado del equipo 4.
curl -s -b admin.cookies -c admin.cookies http://localhost:3000/admin/equipos -o admin-equipos.html
TOKEN=$(grep -o 'name="_csrf" value="[^"]*"' admin-equipos.html | head -1 | cut -d '"' -f 4)
curl -i -b admin.cookies -c admin.cookies -X POST http://localhost:3000/admin/equipos/4/estado \
  --data-urlencode "_csrf=$TOKEN" --data-urlencode 'estado=fuera_de_servicio'

# Consultar todas las reservas y cancelar una reserva activa.
curl -s -b admin.cookies -c admin.cookies http://localhost:3000/admin/reservas -o admin-reservas.html
TOKEN=$(grep -o 'name="_csrf" value="[^"]*"' admin-reservas.html | head -1 | cut -d '"' -f 4)
# Sustituye ID por una reserva activa existente.
curl -i -b admin.cookies -c admin.cookies -X POST http://localhost:3000/admin/reservas/ID/cancelar \
  --data-urlencode "_csrf=$TOKEN"
```

Un usuario normal que intente entrar en `/admin/...` recibe 403. Una petición POST sin token CSRF válido también recibe 403.
