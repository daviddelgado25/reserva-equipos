# Guía breve para explicar la práctica

Esta guía resume cómo explicar el proyecto en la evaluación. Es importante entender el código y practicar la demostración, no memorizar el texto.

## 1. Recorrido de una petición

La aplicación está dividida en capas:

1. **Ruta:** indica la URL, el método HTTP y los middleware que se ejecutan.
2. **Controlador:** lee los datos de la petición, llama al servicio y decide si renderiza una vista o redirige.
3. **Servicio:** contiene las reglas de negocio, por ejemplo comprobar que un equipo está operativo y que no existe otra reserva activa.
4. **Repositorio:** consulta o modifica los arrays en memoria.
5. **Vista EJS:** presenta los datos que recibe. No accede directamente al repositorio.

El servicio no conoce `req`, `res` ni las plantillas. Así se pueden probar las reglas sin hacer una petición HTTP.

## 2. Diferencia entre cookie y sesión

- La cookie `tipoEquipo` recuerda una preferencia de catálogo. Se valida y nunca se utiliza para decidir permisos.
- `express-session` guarda los datos en el servidor. El navegador conserva una cookie con un identificador de sesión.
- La sesión guarda `userId` como identidad, además de datos auxiliares como el token CSRF y el mensaje temporal.
- La cookie de sesión utiliza `httpOnly`, `sameSite`, `maxAge` y `secure` en producción.

El almacén de sesiones predeterminado es MemoryStore y los datos de la aplicación también están en memoria. Por eso el proyecto es didáctico y pierde datos al reiniciar.

## 3. Registro e inicio de sesión

- En el registro se validan nombre, correo y contraseña.
- La contraseña se guarda como hash con bcrypt, nunca en texto claro.
- En el login se compara la contraseña con bcrypt. Si el usuario no existe se realiza una comparación con un hash ficticio para que el mensaje visible no revele si el correo está registrado.
- Después de autenticar, se regenera la sesión y se guarda el identificador del usuario.
- En cada petición, `loadUser` busca al usuario y construye un objeto seguro sin `passwordHash`.
- El logout destruye la sesión y borra la cookie.

## 4. Permisos y CSRF

`requireAuth` comprueba que existe un usuario autenticado. `requireRole("admin")` comprueba su rol, que procede del repositorio del servidor. Para cancelar una reserva también se comprueba que pertenece al usuario que la solicita.

El token CSRF se genera con `crypto.randomBytes`, se guarda en la sesión y se incluye en los formularios POST. El middleware compara el token recibido con el esperado mediante `timingSafeEqual`. Por eso una petición sin token válido no cambia los datos.

## 5. Disponibilidad de equipos

Una reserva se identifica por equipo, fecha y turno. Solo se muestran equipos operativos que no tengan otra reserva activa para esa misma combinación. Una reserva cancelada no bloquea el turno.

El formulario consulta la disponibilidad con GET, pero el servicio repite las comprobaciones al recibir POST. Esto es necesario porque los datos pueden cambiar entre mostrar el formulario y enviarlo.

Después de una operación correcta se utiliza Post/Redirect/Get con una redirección 303 y un mensaje temporal de un solo uso.

## 6. Parte TypeScript

- `types.ts` define las interfaces `Equipo`, `Reserva` y `Usuario`, además de tipos unión para rol, turno y estados.
- `RepositorioReservas` describe las operaciones disponibles.
- `RepositorioReservasMemoria` implementa el contrato con un `Map`.
- `ReservaService` recibe el repositorio por el constructor: es inyección de dependencias.
- `strict: true` obliga a declarar y comprobar los tipos; no se usa `any`.

La parte TypeScript es un núcleo demostrativo independiente. Las rutas Express siguen escritas en JavaScript, tal como permite el enunciado.

## 7. Demostración recomendada

1. Abrir el catálogo y probar los filtros.
2. Registrar una cuenta nueva e iniciar sesión.
3. Abrir el perfil y mostrar que la sesión se mantiene.
4. Consultar disponibilidad para una fecha y turno y crear una reserva.
5. Mostrar `/mis-reservas` y cancelar una reserva propia.
6. Intentar acceder a administración con un usuario normal y comprobar el 403.
7. Entrar como administrador, añadir un equipo y cambiar su estado.
8. Ejecutar `npm run build` y `npm test`.

Para la entrega también hay que publicar el repositorio GitHub y añadir el enlace compartido real del historial de IA al README.
