import express from "express";
import path from "node:path";
import { fileURLToPath } from "node:url";
import cookieParser from "cookie-parser";
import { configurarSesion } from "./config/session.js";
import { config } from "./config/env.js";
import { loadUser } from "./middleware/loadUser.js";
import { prepararCsrf } from "./middleware/csrf.js";
import { flash } from "./middleware/flash.js";
import { preferencias } from "./middleware/preferencias.js";
import routes from "./routes/index.js";
import { notFound, errorHandler } from "./middleware/errorHandler.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
export const app = express();

app.disable("x-powered-by");
if (config.nodeEnv === "production") app.set("trust proxy", 1);
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "../views"));
app.use(express.urlencoded({ extended: false, limit: "20kb" }));
app.use(express.json({ limit: "20kb" }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, "../public")));
app.use(configurarSesion());
app.use(loadUser);
app.use(prepararCsrf);
app.use(flash);
app.use(preferencias);
app.use((req, res, next) => {
  res.locals.usuario = req.usuario;
  next();
});
app.use(routes);
app.use(notFound);
app.use(errorHandler);
