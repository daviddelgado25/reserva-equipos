const entorno = process.env.NODE_ENV ?? "development";
if (!["development", "test", "production"].includes(entorno)) {
  throw new Error("NODE_ENV debe ser development, test o production.");
}

const port = Number(process.env.PORT ?? 3000);
if (!Number.isInteger(port) || port < 1 || port > 65535) {
  throw new Error("PORT debe ser un número entre 1 y 65535.");
}

const sessionSecret = process.env.SESSION_SECRET ?? (
  entorno === "test" ? "secreto-de-pruebas-de-al-menos-32-caracteres" : ""
);
if (sessionSecret.length < 32 || sessionSecret.startsWith("pon_aqui")) {
  throw new Error("SESSION_SECRET debe tener al menos 32 caracteres y no ser el valor de ejemplo.");
}

export const config = Object.freeze({ port, nodeEnv: entorno, sessionSecret });
