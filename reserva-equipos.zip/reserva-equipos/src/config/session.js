import session from "express-session";
import { config } from "./env.js";

export function configurarSesion() {
  return session({
    name: "reserva.sid",
    secret: config.sessionSecret,
    resave: false,
    saveUninitialized: false,
    rolling: true,
    cookie: {
      httpOnly: true,
      secure: config.nodeEnv === "production",
      sameSite: "lax",
      maxAge: 30 * 60 * 1000,
      path: "/"
    }
  });
}
