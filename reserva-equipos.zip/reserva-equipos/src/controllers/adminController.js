import { equipoService } from "../services/equipoService.js";
import { reservaService } from "../services/reservaService.js";

function guardarAvisoYRedirigir(req, res, next, aviso, destino) {
  req.session.aviso = aviso;
  req.session.save(error => error ? next(error) : res.redirect(303, destino));
}

export const adminController = {
  equipos: async (req, res, next) => {
    try {
      const equipos = await equipoService.listar();
      res.render("admin/equipos", { equipos });
    } catch (error) {
      next(error);
    }
  },

  crearEquipo: async (req, res, next) => {
    try {
      await equipoService.crear(req.body);
      guardarAvisoYRedirigir(req, res, next, "Equipo añadido.", "/admin/equipos");
    } catch (error) {
      next(error);
    }
  },

  estado: async (req, res, next) => {
    try {
      await equipoService.cambiarEstado(req.params.id, req.body.estado);
      guardarAvisoYRedirigir(req, res, next, "Estado actualizado.", "/admin/equipos");
    } catch (error) {
      next(error);
    }
  },

  reservas: async (req, res, next) => {
    try {
      const [reservas, equipos] = await Promise.all([
        reservaService.listarTodas(),
        equipoService.listar()
      ]);
      const filas = reservas.map(reserva => ({
        ...reserva,
        equipo: equipos.find(equipo => equipo.id === reserva.equipoId)?.nombre ?? "Equipo"
      }));
      res.render("admin/reservas", { reservas: filas });
    } catch (error) {
      next(error);
    }
  },

  cancelarReserva: async (req, res, next) => {
    try {
      await reservaService.cancelar(req.params.id, req.usuario, true);
      guardarAvisoYRedirigir(req, res, next, "Reserva cancelada por administración.", "/admin/reservas");
    } catch (error) {
      next(error);
    }
  }
};
