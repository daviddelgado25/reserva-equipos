import { authService } from "../services/authService.js";

export const authController = {
  loginForm: (req, res) => res.render("auth/login", { error: null, valores: {} }),

  login: async (req, res, next) => {
    try {
      const usuario = await authService.verificar(req.body.email, req.body.password);
      req.session.regenerate(error => {
        if (error) return next(error);
        req.session.userId = usuario.id;
        req.session.save(errorGuardar => {
          if (errorGuardar) return next(errorGuardar);
          return res.redirect(303, "/perfil");
        });
      });
    } catch (error) {
      if (error.status === 401) {
        return res.status(401).render("auth/login", {
          error: "Credenciales no válidas.",
          valores: { email: String(req.body.email ?? "").slice(0, 120) }
        });
      }
      return next(error);
    }
  },

  registroForm: (req, res) => res.render("auth/registro", { error: null, valores: {} }),

  registro: async (req, res, next) => {
    try {
      await authService.registrar(req.body);
      req.session.aviso = "Cuenta creada. Ya puedes iniciar sesión.";
      req.session.save(error => error ? next(error) : res.redirect(303, "/login"));
    } catch (error) {
      if (error.status && error.status < 500) {
        return res.status(error.status).render("auth/registro", {
          error: error.message,
          valores: {
            nombre: String(req.body.nombre ?? "").slice(0, 80),
            email: String(req.body.email ?? "").slice(0, 120)
          }
        });
      }
      return next(error);
    }
  },

  perfil: (req, res) => res.render("auth/perfil", { usuario: req.usuario }),

  logout: (req, res, next) => {
    req.session.destroy(error => {
      if (error) return next(error);
      res.clearCookie("reserva.sid", {
        path: "/",
        httpOnly: true,
        sameSite: "lax",
        secure: process.env.NODE_ENV === "production"
      });
      return res.redirect(303, "/login");
    });
  }
};
