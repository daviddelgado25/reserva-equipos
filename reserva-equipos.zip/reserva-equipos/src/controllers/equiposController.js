import { equipoService } from "../services/equipoService.js";

export const equiposController = {
  lista: async (req, res, next) => {
    try {
      const filtros = {
        tipo: Object.hasOwn(req.query, "tipo") ? String(req.query.tipo) : res.locals.tipoPreferido,
        estado: req.query.estado || "",
        operativos: req.query.operativos === undefined ? "" : String(req.query.operativos)
      };
      const equipos = await equipoService.listar(filtros);
      res.render("equipos/lista", { equipos, filtros, aviso: res.locals.aviso });
    } catch (error) {
      next(error);
    }
  },
  ficha: async (req, res, next) => {
    try {
      const equipo = await equipoService.obtener(req.params.id);
      res.render("equipos/ficha", { equipo });
    } catch (error) {
      next(error);
    }
  }
};
