import { reservaService } from "../services/reservaService.js";
import { equipoService } from "../services/equipoService.js";
import { reservaFormViewModel } from "../viewmodels/reservaFormViewModel.js";
import { validarReserva, fechaLocalActual } from "../domain/reservas.js";

async function mostrarFormulario(req, res, opciones = {}) {
  const valores = {
    fecha: String(opciones.valores?.fecha ?? req.query.fecha ?? ""),
    turno: String(opciones.valores?.turno ?? req.query.turno ?? ""),
    equipoId: String(opciones.valores?.equipoId ?? "")
  };
  let equipos = [];
  const errores = opciones.errores ?? [];

  if (valores.fecha && valores.turno) {
    try {
      const datos = validarReserva({ equipoId: "1", fecha: valores.fecha, turno: valores.turno });
      equipos = await reservaService.disponibles(datos.fecha, datos.turno);
    } catch (error) {
      errores.push(error.message);
    }
  }

  const vm = reservaFormViewModel({
    equipos,
    csrfToken: res.locals.csrfToken,
    aviso: res.locals.aviso,
    valores,
    errores,
    fechaMinima: fechaLocalActual()
  });
  return res.render("reservas/nueva", { vm });
}

export const reservasController = {
  nueva: async (req, res, next) => {
    try {
      await mostrarFormulario(req, res);
    } catch (error) {
      next(error);
    }
  },
  crear: async (req, res, next) => {
    try {
      await reservaService.crear(req.body, req.usuario);
      req.session.aviso = "Reserva creada correctamente.";
      req.session.save(error => error ? next(error) : res.redirect(303, "/mis-reservas"));
    } catch (error) {
      if (error.status && error.status < 500) {
        try {
          res.status(error.status);
          await mostrarFormulario(req, res, {
            valores: req.body,
            errores: [error.message]
          });
        } catch (errorVista) {
          next(errorVista);
        }
      } else {
        next(error);
      }
    }
  },
  misReservas: async (req, res, next) => {
    try {
      const [reservas, equipos] = await Promise.all([
        reservaService.listar(req.usuario),
        equipoService.listar()
      ]);
      const filas = reservas.map(reserva => ({
        ...reserva,
        equipo: equipos.find(equipo => equipo.id === reserva.equipoId)?.nombre ?? "Equipo"
      }));
      res.render("reservas/mis-reservas", { reservas: filas, fechaHoy: fechaLocalActual() });
    } catch (error) {
      next(error);
    }
  },
  cancelar: async (req, res, next) => {
    try {
      await reservaService.cancelar(req.params.id, req.usuario);
      req.session.aviso = "Reserva cancelada correctamente.";
      req.session.save(error => error ? next(error) : res.redirect(303, "/mis-reservas"));
    } catch (error) {
      next(error);
    }
  }
};
