import bcrypt from "bcrypt";

function fechaDeManana() {
  const fecha = new Date();
  fecha.setDate(fecha.getDate() + 1);
  const local = new Date(fecha.getTime() - fecha.getTimezoneOffset() * 60000);
  return local.toISOString().slice(0, 10);
}

const fecha = fechaDeManana();

export const equipos = [
  { id: 1, codigo: "PC-001", nombre: "Ordenador aula 1", tipo: "sobremesa", estado: "operativo", descripcion: "Ordenador de sobremesa para prácticas." },
  { id: 2, codigo: "PORT-001", nombre: "Portátil Lenovo", tipo: "portatil", estado: "operativo", descripcion: "Portátil para actividades del centro." },
  { id: 3, codigo: "PC-002", nombre: "Ordenador aula 2", tipo: "sobremesa", estado: "fuera_de_servicio", descripcion: "Equipo temporalmente fuera de servicio." },
  { id: 4, codigo: "PROY-001", nombre: "Proyector Epson", tipo: "video", estado: "operativo", descripcion: "Proyector para presentaciones." }
];

export const reservas = [
  { id: 1, equipoId: 1, usuarioId: 2, fecha, turno: "manana", estado: "activa" },
  { id: 2, equipoId: 2, usuarioId: 3, fecha, turno: "tarde", estado: "activa" },
  { id: 3, equipoId: 4, usuarioId: 2, fecha, turno: "manana", estado: "cancelada" }
];

export const usuarios = [
  { id: 1, nombre: "Administrador", email: "admin@example.com", passwordHash: await bcrypt.hash("admin123", 10), rol: "admin" },
  { id: 2, nombre: "Ana García", email: "ana@example.com", passwordHash: await bcrypt.hash("clave123", 10), rol: "usuario" },
  { id: 3, nombre: "Luis Pérez", email: "luis@example.com", passwordHash: await bcrypt.hash("clave123", 10), rol: "usuario" }
];
