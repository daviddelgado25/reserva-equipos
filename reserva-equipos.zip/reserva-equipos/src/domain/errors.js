export class AppError extends Error { constructor(message, status = 400) { super(message); this.status = status; } }
export class ValidationError extends AppError { constructor(m) { super(m, 400); } }
export class NotFoundError extends AppError { constructor(m) { super(m, 404); } }
export class ConflictError extends AppError { constructor(m) { super(m, 409); } }
export class AuthError extends AppError { constructor(m = "Credenciales no válidas") { super(m, 401); } }
export class ForbiddenError extends AppError { constructor(m = "No tienes permiso") { super(m, 403); } }
