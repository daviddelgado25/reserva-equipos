import { ConflictError, ValidationError } from "./errors.js";

export const TURNOS = ["manana", "tarde"];

export function fechaLocalActual() {
  const ahora = new Date();
  const local = new Date(ahora.getTime() - ahora.getTimezoneOffset() * 60000);
  return local.toISOString().slice(0, 10);
}

export function validarReserva(datos, hoy = fechaLocalActual()) {
  const equipoTexto = datos.equipoId;
  const equipoId = typeof equipoTexto === "string" && /^[1-9]\d*$/.test(equipoTexto)
    ? Number(equipoTexto)
    : typeof equipoTexto === "number" ? equipoTexto : NaN;
  const fecha = typeof datos.fecha === "string" ? datos.fecha : "";
  const turno = typeof datos.turno === "string" ? datos.turno : "";

  if (!Number.isSafeInteger(equipoId) || equipoId < 1) {
    throw new ValidationError("Selecciona un equipo válido.");
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(fecha)) {
    throw new ValidationError("Introduce una fecha válida.");
  }
  const fechaReal = new Date(`${fecha}T00:00:00.000Z`);
  if (Number.isNaN(fechaReal.getTime()) || fechaReal.toISOString().slice(0, 10) !== fecha) {
    throw new ValidationError("Introduce una fecha válida.");
  }
  if (fecha < hoy) {
    throw new ValidationError("La fecha no puede ser anterior a hoy.");
  }
  if (!TURNOS.includes(turno)) {
    throw new ValidationError("Selecciona mañana o tarde.");
  }
  return { equipoId, fecha, turno };
}

export function estaReservado(equipoId, fecha, turno, reservas) {
  return reservas.some(reserva =>
    reserva.equipoId === equipoId &&
    reserva.fecha === fecha &&
    reserva.turno === turno &&
    reserva.estado === "activa"
  );
}

export function obtenerEquiposDisponibles(equipos, reservas, fecha, turno) {
  if (!fecha || !TURNOS.includes(turno)) return [];
  return equipos.filter(equipo =>
    equipo.estado === "operativo" &&
    !estaReservado(equipo.id, fecha, turno, reservas)
  );
}

export function comprobarConflicto(equipoId, reservas, fecha, turno) {
  if (estaReservado(equipoId, fecha, turno, reservas)) {
    throw new ConflictError("El equipo ya está reservado para esa fecha y turno.");
  }
}
