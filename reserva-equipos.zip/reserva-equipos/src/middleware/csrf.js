import crypto from "node:crypto";

export function prepararCsrf(req, res, next) {
  if (!req.session.csrfToken) {
    req.session.csrfToken = crypto.randomBytes(32).toString("hex");
  }
  res.locals.csrfToken = req.session.csrfToken;
  next();
}

export function comprobarCsrf(req, res, next) {
  const esperado = req.session?.csrfToken;
  const recibido = req.body?._csrf;
  const tokenGuardado = Buffer.from(typeof esperado === "string" ? esperado : "");
  const tokenRecibido = Buffer.from(typeof recibido === "string" ? recibido : "");

  if (
    tokenGuardado.length !== 64 ||
    tokenRecibido.length !== tokenGuardado.length ||
    !crypto.timingSafeEqual(tokenGuardado, tokenRecibido)
  ) {
    return res.status(403).render("error", {
      mensaje: "La petición no ha superado la comprobación de seguridad."
    });
  }
  return next();
}
