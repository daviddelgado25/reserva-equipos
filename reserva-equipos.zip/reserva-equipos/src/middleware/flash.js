export function flash(req, res, next) { res.locals.aviso = req.session.aviso ?? null; delete req.session.aviso; next(); }
