import { rateLimit } from "express-rate-limit";
import { config } from "../config/env.js";

export const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: config.nodeEnv === "test" ? 1000 : 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: "Demasiados intentos. Prueba más tarde."
});
