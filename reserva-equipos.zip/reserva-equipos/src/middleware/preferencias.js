const TIPOS_VALIDOS = ["portatil", "sobremesa"];

export function preferencias(req, res, next) {
  const valor = req.cookies?.tipoEquipo;
  res.locals.tipoPreferido = TIPOS_VALIDOS.includes(valor) ? valor : "";
  next();
}

export function guardarPreferencia(req, res, next) {
  const tipo = String(req.body.tipo ?? "");
  if (tipo !== "" && !TIPOS_VALIDOS.includes(tipo)) {
    return res.status(400).render("error", { mensaje: "La preferencia seleccionada no es válida." });
  }
  if (tipo) {
    res.cookie("tipoEquipo", tipo, {
      maxAge: 30 * 24 * 60 * 60 * 1000,
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax"
    });
  } else {
    res.clearCookie("tipoEquipo", { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production" });
  }
  return res.redirect(303, "/equipos");
}
