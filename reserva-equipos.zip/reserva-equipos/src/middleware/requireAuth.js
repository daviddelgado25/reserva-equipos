export function requireAuth(req, res, next) { if (!req.usuario) return res.redirect(303, "/login"); next(); }
