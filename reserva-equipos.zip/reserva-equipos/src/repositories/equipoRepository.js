import { equipos } from "../data/seed.js";

export const equipoRepository = {
  async listar() {
    return equipos.map(equipo => ({ ...equipo }));
  },

  async buscar(id) {
    const equipo = equipos.find(elemento => elemento.id === Number(id));
    return equipo ? { ...equipo } : null;
  },

  async crear(datos) {
    const id = Math.max(0, ...equipos.map(equipo => equipo.id)) + 1;
    const nuevo = { id, ...datos };
    equipos.push(nuevo);
    return { ...nuevo };
  },

  async guardar(equipo) {
    const indice = equipos.findIndex(elemento => elemento.id === equipo.id);
    if (indice < 0) return null;
    equipos[indice] = { ...equipo };
    return { ...equipo };
  }
};
