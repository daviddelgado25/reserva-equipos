import { reservas } from "../data/seed.js";

export const reservaRepository = {
  async listar() {
    return reservas.map(reserva => ({ ...reserva }));
  },

  async buscar(id) {
    const reserva = reservas.find(elemento => elemento.id === Number(id));
    return reserva ? { ...reserva } : null;
  },

  async crear(datos) {
    const id = Math.max(0, ...reservas.map(reserva => reserva.id)) + 1;
    const nueva = { id, ...datos };
    reservas.push(nueva);
    return { ...nueva };
  },

  async guardar(reserva) {
    const indice = reservas.findIndex(elemento => elemento.id === reserva.id);
    if (indice < 0) return null;
    reservas[indice] = { ...reserva };
    return { ...reserva };
  }
};
