import { usuarios } from "../data/seed.js";

export const usuarioRepository = {
  async listar() {
    return usuarios.map(({ passwordHash, ...usuario }) => ({ ...usuario }));
  },

  async buscarPorEmail(email) {
    return usuarios.find(usuario => usuario.email === email) ?? null;
  },

  async buscarPorId(id) {
    return usuarios.find(usuario => usuario.id === Number(id)) ?? null;
  },

  async crear(datos) {
    const id = Math.max(0, ...usuarios.map(usuario => usuario.id)) + 1;
    const nuevo = { id, ...datos };
    usuarios.push(nuevo);
    return nuevo;
  }
};
