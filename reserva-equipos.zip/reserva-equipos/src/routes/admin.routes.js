import { Router } from "express";
import { adminController } from "../controllers/adminController.js";
import { requireRole } from "../middleware/requireRole.js";
import { comprobarCsrf } from "../middleware/csrf.js";

const router = Router();
router.get("/admin/equipos", requireRole("admin"), adminController.equipos);
router.post("/admin/equipos", requireRole("admin"), comprobarCsrf, adminController.crearEquipo);
router.post("/admin/equipos/:id/estado", requireRole("admin"), comprobarCsrf, adminController.estado);
router.get("/admin/reservas", requireRole("admin"), adminController.reservas);
router.post("/admin/reservas/:id/cancelar", requireRole("admin"), comprobarCsrf, adminController.cancelarReserva);
export default router;
