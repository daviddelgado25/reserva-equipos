import { Router } from "express";
import { authController } from "../controllers/authController.js";
import { loginLimiter } from "../middleware/loginLimiter.js";
import { requireAuth } from "../middleware/requireAuth.js";
import { comprobarCsrf } from "../middleware/csrf.js";

const router = Router();
router.get("/registro", authController.registroForm);
router.post("/registro", comprobarCsrf, authController.registro);
router.get("/login", authController.loginForm);
router.post("/login", loginLimiter, comprobarCsrf, authController.login);
router.post("/logout", requireAuth, comprobarCsrf, authController.logout);
router.get("/perfil", requireAuth, authController.perfil);
export default router;
