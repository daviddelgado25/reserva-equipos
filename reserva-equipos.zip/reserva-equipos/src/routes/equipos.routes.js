import { Router } from "express"; import { equiposController } from "../controllers/equiposController.js";
const router = Router(); router.get("/equipos", equiposController.lista); router.get("/equipos/:id", equiposController.ficha); export default router;
