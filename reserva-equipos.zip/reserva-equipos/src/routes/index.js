import { Router } from "express";
import equipos from "./equipos.routes.js";
import auth from "./auth.routes.js";
import reservas from "./reservas.routes.js";
import admin from "./admin.routes.js";
import preferencias from "./preferencias.routes.js";

const router = Router();
router.use(equipos, auth, reservas, admin, preferencias);
router.get("/", (req, res) => res.redirect(303, "/equipos"));
export default router;
