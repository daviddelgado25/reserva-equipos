import { Router } from "express";
import { guardarPreferencia } from "../middleware/preferencias.js";
import { comprobarCsrf } from "../middleware/csrf.js";

const router = Router();
router.post("/preferencias", comprobarCsrf, guardarPreferencia);
export default router;
