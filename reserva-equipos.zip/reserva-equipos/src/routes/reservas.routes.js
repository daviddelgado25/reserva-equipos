import { Router } from "express";
import { reservasController } from "../controllers/reservasController.js";
import { requireAuth } from "../middleware/requireAuth.js";
import { comprobarCsrf } from "../middleware/csrf.js";

const router = Router();
router.get("/reservas/nueva", requireAuth, reservasController.nueva);
router.post("/reservas", requireAuth, comprobarCsrf, reservasController.crear);
router.get("/mis-reservas", requireAuth, reservasController.misReservas);
router.post("/reservas/:id/cancelar", requireAuth, comprobarCsrf, reservasController.cancelar);
export default router;
