import bcrypt from "bcrypt";
import { usuarioRepository } from "../repositories/usuarioRepository.js";
import { ValidationError, ConflictError, AuthError } from "../domain/errors.js";

// Se compara también cuando el correo no existe para no revelar qué cuentas están registradas.
const dummyHash = await bcrypt.hash("clave-incorrecta-para-comparacion", 12);

export const authService = {
  async registrar(datos) {
    const nombre = String(datos.nombre ?? "").trim();
    const email = String(datos.email ?? "").trim().toLowerCase();
    const password = String(datos.password ?? "");

    const passwordValida = password.length >= 8 && Buffer.byteLength(password, "utf8") <= 72;
    const emailValido = email.length <= 254 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    if (nombre.length < 2 || nombre.length > 80 || !emailValido || !passwordValida) {
      throw new ValidationError("Introduce un nombre, un correo válido y una contraseña de al menos 8 caracteres.");
    }

    if (await usuarioRepository.buscarPorEmail(email)) {
      throw new ConflictError("No se puede crear la cuenta con esos datos.");
    }

    const passwordHash = await bcrypt.hash(password, 12);
    return usuarioRepository.crear({ nombre, email, passwordHash, rol: "usuario" });
  },

  async verificar(emailRecibido, passwordRecibida) {
    const email = String(emailRecibido ?? "").trim().toLowerCase();
    const password = String(passwordRecibida ?? "");
    const usuario = await usuarioRepository.buscarPorEmail(email);
    if (Buffer.byteLength(password, "utf8") > 72) throw new AuthError();
    const hash = usuario ? usuario.passwordHash : dummyHash;
    const coincide = await bcrypt.compare(password, hash);

    if (!usuario || !coincide) throw new AuthError();
    const { passwordHash, ...usuarioSeguro } = usuario;
    return usuarioSeguro;
  }
};
