import { equipoRepository } from "../repositories/equipoRepository.js";
import { NotFoundError, ValidationError, ConflictError } from "../domain/errors.js";

const TIPOS = ["portatil", "sobremesa", "video"];
const ESTADOS = ["operativo", "fuera_de_servicio"];

export const equipoService = {
  async listar(filtros = {}) {
    if (filtros.tipo && !TIPOS.includes(filtros.tipo)) {
      throw new ValidationError("El tipo de equipo seleccionado no es válido.");
    }
    if (filtros.estado && !ESTADOS.includes(filtros.estado)) {
      throw new ValidationError("El estado seleccionado no es válido.");
    }
    if (filtros.operativos && filtros.operativos !== "true" && filtros.operativos !== "false") {
      throw new ValidationError("El filtro de equipos operativos no es válido.");
    }

    let equipos = await equipoRepository.listar();
    if (filtros.tipo) equipos = equipos.filter(equipo => equipo.tipo === filtros.tipo);
    if (filtros.estado) equipos = equipos.filter(equipo => equipo.estado === filtros.estado);
    if (filtros.operativos === "true") equipos = equipos.filter(equipo => equipo.estado === "operativo");
    return equipos;
  },

  async obtener(id) {
    const textoId = String(id);
    if (!/^[1-9]\d*$/.test(textoId)) throw new NotFoundError("Equipo no encontrado.");
    const numero = Number(textoId);
    if (!Number.isSafeInteger(numero)) throw new NotFoundError("Equipo no encontrado.");
    const equipo = await equipoRepository.buscar(numero);
    if (!equipo) throw new NotFoundError("Equipo no encontrado.");
    return equipo;
  },

  async crear(datos) {
    const nombre = String(datos.nombre ?? "").trim();
    const codigo = String(datos.codigo ?? "").trim().toUpperCase();
    const tipo = String(datos.tipo ?? "");
    if (nombre.length < 3 || nombre.length > 100 || !/^[A-Z0-9-]{3,20}$/.test(codigo) || !TIPOS.includes(tipo)) {
      throw new ValidationError("Revisa el nombre, código y tipo del equipo.");
    }
    const equipos = await equipoRepository.listar();
    if (equipos.some(equipo => equipo.codigo === codigo)) {
      throw new ConflictError("Ese código ya está registrado.");
    }
    return equipoRepository.crear({
      codigo,
      nombre,
      tipo,
      estado: "operativo",
      descripcion: String(datos.descripcion ?? "").trim().slice(0, 250)
    });
  },

  async cambiarEstado(id, estado) {
    if (!ESTADOS.includes(estado)) throw new ValidationError("Estado no válido.");
    const equipo = await this.obtener(id);
    return equipoRepository.guardar({ ...equipo, estado });
  }
};
