import { equipoRepository } from "../repositories/equipoRepository.js";
import { reservaRepository } from "../repositories/reservaRepository.js";
import {
  comprobarConflicto,
  obtenerEquiposDisponibles,
  validarReserva,
  fechaLocalActual
} from "../domain/reservas.js";
import { ConflictError, ForbiddenError, NotFoundError } from "../domain/errors.js";

export const reservaService = {
  async disponibles(fecha, turno) {
    const [equipos, reservas] = await Promise.all([
      equipoRepository.listar(),
      reservaRepository.listar()
    ]);
    return obtenerEquiposDisponibles(equipos, reservas, fecha, turno);
  },

  async crear(datos, usuario) {
    const validos = validarReserva(datos);
    const equipo = await equipoRepository.buscar(validos.equipoId);

    if (!equipo) throw new NotFoundError("El equipo seleccionado no existe.");
    if (equipo.estado !== "operativo") {
      throw new ConflictError("El equipo no está operativo.");
    }

    const reservas = await reservaRepository.listar();
    comprobarConflicto(equipo.id, reservas, validos.fecha, validos.turno);

    return reservaRepository.crear({
      ...validos,
      usuarioId: usuario.id,
      estado: "activa"
    });
  },

  async cancelar(id, usuario, administracion = false) {
    const textoId = String(id);
    if (!/^[1-9]\d*$/.test(textoId) || !Number.isSafeInteger(Number(textoId))) {
      throw new NotFoundError("Reserva no encontrada.");
    }
    const reserva = await reservaRepository.buscar(Number(textoId));
    if (!reserva) throw new NotFoundError("Reserva no encontrada.");
    if (!administracion && reserva.usuarioId !== usuario.id) {
      throw new ForbiddenError("No puedes cancelar una reserva de otra persona.");
    }
    if (reserva.estado !== "activa") {
      throw new ConflictError("La reserva ya está cancelada.");
    }
    if (!administracion && reserva.fecha < fechaLocalActual()) {
      throw new ConflictError("No puedes cancelar una reserva cuya fecha ya ha pasado.");
    }

    return reservaRepository.guardar({ ...reserva, estado: "cancelada" });
  },

  async listar(usuario) {
    const reservas = await reservaRepository.listar();
    return reservas.filter(reserva => reserva.usuarioId === usuario.id);
  },

  async listarTodas() {
    return reservaRepository.listar();
  }
};
