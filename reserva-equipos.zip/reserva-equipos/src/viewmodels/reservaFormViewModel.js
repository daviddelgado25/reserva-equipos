export function reservaFormViewModel({ equipos, csrfToken, aviso = null, valores = {}, errores = [], fechaMinima }) {
  return {
    titulo: "Nueva reserva",
    equipos: equipos.map(equipo => ({
      valor: String(equipo.id),
      texto: `${equipo.nombre} (${equipo.codigo})`
    })),
    puedeEnviar: equipos.length > 0,
    csrfToken,
    aviso,
    valores,
    errores,
    fechaMinima
  };
}
