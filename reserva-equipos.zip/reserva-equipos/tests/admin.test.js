import { describe, it, expect } from "vitest";
import { cliente, tokenCsrf } from "./helpers.js";
import { reservaRepository } from "../src/repositories/reservaRepository.js";

describe("Administración", () => {
  it("el administrador puede ver la gestión de equipos", async () => {
    const agente = cliente();
    const token = await tokenCsrf(agente);
    await agente.post("/login").type("form").send({ _csrf: token, email: "admin@example.com", password: "admin123" });
    expect((await agente.get("/admin/equipos")).status).toBe(200);
  });

  it("el administrador puede consultar todas las reservas", async () => {
    const agente = cliente();
    const token = await tokenCsrf(agente);
    await agente.post("/login").type("form").send({ _csrf: token, email: "admin@example.com", password: "admin123" });
    expect((await agente.get("/admin/reservas")).status).toBe(200);
  });

  it("el administrador puede cancelar una reserva activa", async () => {
    const fecha = new Date();
    fecha.setDate(fecha.getDate() + 30);
    const local = new Date(fecha.getTime() - fecha.getTimezoneOffset() * 60000);
    const reserva = await reservaRepository.crear({
      equipoId: 1,
      usuarioId: 2,
      fecha: local.toISOString().slice(0, 10),
      turno: "tarde",
      estado: "activa"
    });

    const agente = cliente();
    const token = await tokenCsrf(agente);
    await agente.post("/login").type("form").send({ _csrf: token, email: "admin@example.com", password: "admin123" });
    const pagina = await agente.get("/admin/reservas");
    const csrf = pagina.text.match(/name="_csrf" value="([^"]+)"/)?.[1];
    const respuesta = await agente.post(`/admin/reservas/${reserva.id}/cancelar`).type("form").send({ _csrf: csrf });
    expect(respuesta.status).toBe(303);
    expect((await reservaRepository.buscar(reserva.id)).estado).toBe("cancelada");
  });

  it("el administrador puede añadir un equipo", async () => {
    const agente = cliente();
    const token = await tokenCsrf(agente);
    await agente.post("/login").type("form").send({ _csrf: token, email: "admin@example.com", password: "admin123" });
    const pagina = await agente.get("/admin/equipos");
    const csrf = pagina.text.match(/name="_csrf" value="([^"]+)"/)?.[1];
    const respuesta = await agente.post("/admin/equipos").type("form").send({
      _csrf: csrf,
      codigo: "TEST-" + Date.now(),
      nombre: "Equipo de pruebas",
      tipo: "portatil",
      descripcion: "Alta desde una prueba automatizada"
    });
    expect(respuesta.status).toBe(303);
  });
});
