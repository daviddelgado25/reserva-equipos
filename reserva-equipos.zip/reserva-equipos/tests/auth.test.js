import { describe,it,expect } from "vitest"; import { cliente, tokenCsrf, iniciar } from "./helpers.js";
describe("Autenticación",()=>{
 it("registra un usuario válido",async()=>{ const a=cliente(); const t=await tokenCsrf(a,"/registro"); const r=await a.post("/registro").type("form").send({_csrf:t,nombre:"Usuario Nuevo",email:"nuevo-"+Date.now()+"@example.com",password:"contrasena123"}); expect(r.status).toBe(303); });
 it("rechaza credenciales incorrectas",async()=>{ const a=cliente(); const t=await tokenCsrf(a); const r=await a.post("/login").type("form").send({_csrf:t,email:"ana@example.com",password:"mal"}); expect(r.status).toBe(401); });
 it("redirige al login si no hay sesión",async()=>{ expect((await cliente().get("/perfil")).status).toBe(303); });
 it("permite entrar en perfil con sesión",async()=>{ const a=cliente(); await iniciar(a); expect((await a.get("/perfil")).status).toBe(200); });
 it("el usuario normal no entra en administración",async()=>{ const a=cliente(); await iniciar(a); expect((await a.get("/admin/equipos")).status).toBe(403); });
 it("el logout invalida la sesión",async()=>{ const a=cliente(); await iniciar(a); const t=await tokenCsrf(a,"/perfil"); expect((await a.post("/logout").type("form").send({_csrf:t})).status).toBe(303); expect((await a.get("/perfil")).status).toBe(303); });
});
