import { app } from "../src/app.js"; import request from "supertest";
export function cliente() { return request.agent(app); }
export async function tokenCsrf(agent, ruta = "/login") { const r = await agent.get(ruta); const m = r.text.match(/name="_csrf" value="([^"]+)"/); if (!m) throw new Error("No se ha encontrado el token CSRF"); return m[1]; }
export async function iniciar(agent,email="ana@example.com",password="clave123") { const token = await tokenCsrf(agent); return agent.post("/login").type("form").send({ _csrf:token,email,password }); }
