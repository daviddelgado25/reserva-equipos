import { describe, it, expect } from "vitest";
import { cliente, iniciar, tokenCsrf } from "./helpers.js";
import { reservas } from "../src/data/seed.js";

const fechaLibre = () => {
  const fecha = new Date();
  fecha.setDate(fecha.getDate() + 20);
  const local = new Date(fecha.getTime() - fecha.getTimezoneOffset() * 60000);
  return local.toISOString().slice(0, 10);
};

describe("Reservas", () => {
  it("crea una reserva válida", async () => {
    const agente = cliente();
    await iniciar(agente);
    const fecha = fechaLibre();
    const token = await tokenCsrf(agente, "/reservas/nueva");
    const respuesta = await agente.post("/reservas").type("form").send({
      _csrf: token, equipoId: "4", fecha, turno: "tarde"
    });
    expect(respuesta.status).toBe(303);
    expect(respuesta.headers.location).toBe("/mis-reservas");
  });

  it("rechaza una reserva duplicada", async () => {
    const agente = cliente();
    await iniciar(agente);
    const token = await tokenCsrf(agente, "/reservas/nueva");
    const respuesta = await agente.post("/reservas").type("form").send({
      _csrf: token, equipoId: "1", fecha: reservas[0].fecha, turno: "manana"
    });
    expect(respuesta.status).toBe(409);
  });

  it("impide cancelar una reserva de otro usuario", async () => {
    const agente = cliente();
    await iniciar(agente);
    const token = await tokenCsrf(agente, "/mis-reservas");
    const respuesta = await agente.post("/reservas/2/cancelar").type("form").send({ _csrf: token });
    expect(respuesta.status).toBe(403);
  });

  it("rechaza una modificación sin token CSRF válido", async () => {
    const agente = cliente();
    const token = await tokenCsrf(agente);
    await agente.post("/login").type("form").send({ _csrf: token, email: "admin@example.com", password: "admin123" });
    const respuesta = await agente.post("/admin/equipos/1/estado").type("form").send({ estado: "fuera_de_servicio" });
    expect(respuesta.status).toBe(403);
  });

  it("rechaza reservar un equipo fuera de servicio", async () => {
    const agente = cliente();
    await iniciar(agente);
    const token = await tokenCsrf(agente, "/reservas/nueva");
    const respuesta = await agente.post("/reservas").type("form").send({
      _csrf: token, equipoId: "3", fecha: fechaLibre(), turno: "manana"
    });
    expect(respuesta.status).toBe(409);
  });

  it("una reserva cancelada deja libre el turno", async () => {
    const ana = cliente();
    await iniciar(ana);
    const fecha = new Date();
    fecha.setDate(fecha.getDate() + 21);
    const local = new Date(fecha.getTime() - fecha.getTimezoneOffset() * 60000);
    const fechaTexto = local.toISOString().slice(0, 10);
    let token = await tokenCsrf(ana, "/reservas/nueva");
    const creada = await ana.post("/reservas").type("form").send({
      _csrf: token, equipoId: "4", fecha: fechaTexto, turno: "manana"
    });
    expect(creada.status).toBe(303);
    const reservaNueva = reservas.find(reserva =>
      reserva.equipoId === 4 && reserva.fecha === fechaTexto && reserva.turno === "manana" && reserva.estado === "activa"
    );
    expect(reservaNueva).toBeTruthy();

    token = await tokenCsrf(ana, "/mis-reservas");
    expect((await ana.post(`/reservas/${reservaNueva.id}/cancelar`).type("form").send({ _csrf: token })).status).toBe(303);
    expect(reservas.find(reserva => reserva.id === reservaNueva.id).estado).toBe("cancelada");

    const luis = cliente();
    await iniciar(luis, "luis@example.com", "clave123");
    token = await tokenCsrf(luis, "/reservas/nueva");
    const nuevaReserva = await luis.post("/reservas").type("form").send({
      _csrf: token, equipoId: "4", fecha: fechaTexto, turno: "manana"
    });
    expect(nuevaReserva.status).toBe(303);
  });

  it("muestra solo equipos disponibles para la fecha y el turno", async () => {
    const agente = cliente();
    await iniciar(agente);
    const fecha = fechaLibre();
    const respuesta = await agente.get(`/reservas/nueva?fecha=${fecha}&turno=manana`);
    expect(respuesta.status).toBe(200);
    expect(respuesta.text).toContain("Ordenador aula 1");
  });
});
