import { describe, it, expect } from "vitest";
import { RepositorioReservasMemoria } from "../ts/RepositorioReservasMemoria.ts";
import { ReservaService } from "../ts/ReservaService.ts";

const ana = { id: 2, nombre: "Ana García", email: "ana@example.com", rol: "usuario" };

describe("Núcleo TypeScript", () => {
  it("detecta una reserva activa mediante Map e inyección de dependencias", async () => {
    const repo = new RepositorioReservasMemoria([{
      id: 1, equipoId: 1, usuarioId: 2, fecha: "2027-01-15", turno: "manana", estado: "activa"
    }]);
    const servicio = new ReservaService(repo);
    expect(await servicio.estaReservado(1, "2027-01-15", "manana")).toBe(true);
  });

  it("crea una reserva con el usuario recibido y el siguiente identificador", async () => {
    const repo = new RepositorioReservasMemoria([]);
    const servicio = new ReservaService(repo);
    const fecha = new Date();
    fecha.setDate(fecha.getDate() + 10);
    const local = new Date(fecha.getTime() - fecha.getTimezoneOffset() * 60000);
    const fechaTexto = local.toISOString().slice(0, 10);
    const creada = await servicio.crear(4, fechaTexto, "tarde", ana);
    expect(creada.usuarioId).toBe(2);
    expect(creada.id).toBe(1);
    expect(await servicio.estaReservado(4, fechaTexto, "tarde")).toBe(true);
  });
});
