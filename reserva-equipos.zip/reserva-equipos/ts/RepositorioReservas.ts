import type { Reserva } from "./types.js";

export interface RepositorioReservas {
  listar(): Promise<Reserva[]>;
  buscarPorId(id: number): Promise<Reserva | undefined>;
  guardar(reserva: Reserva): Promise<void>;
  crear(reserva: Reserva): Promise<void>;
}
