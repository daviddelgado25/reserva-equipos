import type { Reserva } from "./types.js";
import type { RepositorioReservas } from "./RepositorioReservas.js";

export class RepositorioReservasMemoria implements RepositorioReservas {
  private readonly datos: Map<number, Reserva>;

  constructor(iniciales: readonly Reserva[] = []) {
    this.datos = new Map(iniciales.map(reserva => [reserva.id, { ...reserva }]));
  }

  async listar(): Promise<Reserva[]> {
    return [...this.datos.values()].map(reserva => ({ ...reserva }));
  }

  async buscarPorId(id: number): Promise<Reserva | undefined> {
    const reserva = this.datos.get(id);
    return reserva ? { ...reserva } : undefined;
  }

  async guardar(reserva: Reserva): Promise<void> {
    if (!this.datos.has(reserva.id)) throw new Error("La reserva no existe.");
    this.datos.set(reserva.id, { ...reserva });
  }

  async crear(reserva: Reserva): Promise<void> {
    if (this.datos.has(reserva.id)) throw new Error("La reserva ya existe.");
    this.datos.set(reserva.id, { ...reserva });
  }
}
