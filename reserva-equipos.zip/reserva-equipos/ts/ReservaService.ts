import type { Reserva, Turno, Usuario } from "./types.js";
import type { RepositorioReservas } from "./RepositorioReservas.js";

export class ReservaService {
  constructor(private readonly repo: RepositorioReservas) {}

  async estaReservado(equipoId: number, fecha: string, turno: Turno): Promise<boolean> {
    const reservas = await this.repo.listar();
    return reservas.some(reserva =>
      reserva.equipoId === equipoId &&
      reserva.fecha === fecha &&
      reserva.turno === turno &&
      reserva.estado === "activa"
    );
  }

  async crear(equipoId: number, fecha: string, turno: Turno, usuario: Usuario): Promise<Reserva> {
    if (!Number.isSafeInteger(equipoId) || equipoId < 1) throw new Error("Equipo no válido.");
    if (!/^\d{4}-\d{2}-\d{2}$/.test(fecha)) throw new Error("Fecha no válida.");
    const fechaReal = new Date(`${fecha}T00:00:00.000Z`);
    if (Number.isNaN(fechaReal.getTime()) || fechaReal.toISOString().slice(0, 10) !== fecha) {
      throw new Error("Fecha no válida.");
    }
    if (fecha < new Date().toISOString().slice(0, 10)) throw new Error("La fecha ya ha pasado.");
    if (turno !== "manana" && turno !== "tarde") throw new Error("Turno no válido.");
    if (await this.estaReservado(equipoId, fecha, turno)) throw new Error("El equipo ya está reservado.");

    const reservas = await this.repo.listar();
    const reserva: Reserva = {
      id: reservas.reduce((mayor, actual) => Math.max(mayor, actual.id), 0) + 1,
      equipoId,
      usuarioId: usuario.id,
      fecha,
      turno,
      estado: "activa"
    };
    await this.repo.crear(reserva);
    return reserva;
  }

  async cancelar(id: number, usuario: Usuario, esAdmin = false): Promise<Reserva> {
    const reserva = await this.repo.buscarPorId(id);
    if (!reserva) throw new Error("Reserva no encontrada.");
    if (!esAdmin && reserva.usuarioId !== usuario.id) throw new Error("No puedes cancelar esta reserva.");
    if (reserva.estado !== "activa") throw new Error("La reserva ya está cancelada.");
    if (!esAdmin && reserva.fecha < new Date().toISOString().slice(0, 10)) {
      throw new Error("No puedes cancelar una reserva pasada.");
    }
    const actualizada: Reserva = { ...reserva, estado: "cancelada" };
    await this.repo.guardar(actualizada);
    return actualizada;
  }
}
