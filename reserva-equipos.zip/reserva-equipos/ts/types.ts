export type Rol = "usuario" | "admin";
export type Turno = "manana" | "tarde";
export type EstadoReserva = "activa" | "cancelada";
export type EstadoEquipo = "operativo" | "fuera_de_servicio";
export type TipoEquipo = "portatil" | "sobremesa" | "video";

export interface Equipo {
  readonly id: number;
  readonly codigo: string;
  readonly nombre: string;
  readonly tipo: TipoEquipo;
  readonly estado: EstadoEquipo;
}

export interface Usuario {
  readonly id: number;
  readonly nombre: string;
  readonly email: string;
  readonly rol: Rol;
}

export interface Reserva {
  readonly id: number;
  readonly equipoId: number;
  readonly usuarioId: number;
  readonly fecha: string;
  readonly turno: Turno;
  readonly estado: EstadoReserva;
}
