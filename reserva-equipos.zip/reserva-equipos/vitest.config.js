import { defineConfig } from "vitest/config";

process.env.NODE_ENV = "test";
process.env.SESSION_SECRET ??= "secreto-de-pruebas-de-al-menos-32-caracteres";

export default defineConfig({
  test: {
    environment: "node",
    testTimeout: 15000
  }
});
